rm HappyNumber.class
javac HappyNumber.java Input.java
java HappyNumber