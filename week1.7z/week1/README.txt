/////////////////////////README: Homework Summary of 1st week///////////////////////////////////

1. I have completed all assignments.
2. copy list with random pointers and bulls and cows are what I have already done in leetcode. I am submitting the submission version and I will be ready to explain the problem.
3. I have hardships in the ideas of the two problems:
3a. container with most water
3b. remove overlapping intervals
Especially in 3b. Every single comparator comparing the end will pass the leetcode autocheck, but will cause mismatch when put on my randomized autotesting.  I think I may need to examine if my current thoughts are right.


Thanks again for the effort in the homeworks and I am further looking forward to improving myself.

Best,
Yefei Wang