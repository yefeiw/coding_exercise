rm SimplifyPath.class
javac SimplifyPath.java Input.java
java SimplifyPath