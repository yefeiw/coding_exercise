rm EvalRPN.class
javac EvalRPN.java Input.java
java EvalRPN