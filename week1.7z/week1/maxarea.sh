rm MaxArea.class
javac MaxArea.java Input.java
java MaxArea