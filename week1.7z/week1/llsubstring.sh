rm LongestSubString.class
javac LongestSubString.java Input.java
java LongestSubString