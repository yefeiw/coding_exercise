rm ThreeSumClosest.class
javac ThreeSumClosest.java Input.java
java ThreeSumClosest