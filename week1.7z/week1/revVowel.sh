rm ReverseVowel.class
javac ReverseVowel.java Input.java
java ReverseVowel