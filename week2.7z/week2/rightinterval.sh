cd src
rm *.class
javac findRightInterval.java Input.java 
java findRightInterval
cd ..