I have written the source code for all interval problems, and chose to do the tree-related problems on leetcode.

I have doubts understanding the problem of in-order successor, and I think I may need some more graphing to fully understand that problem without seeking help.

