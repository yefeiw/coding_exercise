cd src
rm sqrt.class
javac sqrt.java Input.java
java sqrt
cd ..